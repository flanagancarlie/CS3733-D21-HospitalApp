package edu.wpi.teamC.entities;

public class Administrator extends HospitalUser{

    public Administrator(String user, String userEmail, String pass, String first, String last) {
        super(user,userEmail,pass,first,last);
    }

}
