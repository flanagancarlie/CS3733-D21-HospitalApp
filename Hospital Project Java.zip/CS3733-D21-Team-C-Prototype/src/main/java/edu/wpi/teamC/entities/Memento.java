package edu.wpi.teamC.entities;

public class Memento {
    public String fxml;

    public Memento(String fxml) {
        this.fxml = fxml;
    }
}
