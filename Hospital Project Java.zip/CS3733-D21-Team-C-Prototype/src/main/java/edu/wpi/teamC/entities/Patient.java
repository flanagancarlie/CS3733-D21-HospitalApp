package edu.wpi.teamC.entities;

public class Patient extends HospitalUser {

    public Patient(String userName, String userEmail, String password, String firstName, String lastName) {
        super(userName,userEmail,password,firstName,lastName);
    }
}
