package edu.wpi.teamC.entities.mapEditor;

public interface ISearch {
    public MultiFloorPath search(Node start, Node goal,boolean isEmergency);

}
