package edu.wpi.teamC.views.serviceRequest;

public interface ITreeMenuControllerAlternate {
    public void setLocationAlternate(String shortName);
    ITreeMenuControllerAlternate getThisAlternate();
}
